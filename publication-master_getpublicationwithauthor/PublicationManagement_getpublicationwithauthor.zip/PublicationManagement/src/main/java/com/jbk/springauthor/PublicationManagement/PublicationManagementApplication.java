package com.jbk.springauthor.PublicationManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PublicationManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PublicationManagementApplication.class, args);
	}

}
